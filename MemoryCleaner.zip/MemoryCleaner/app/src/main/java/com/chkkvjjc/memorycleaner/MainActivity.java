package com.chkkvjjc.memorycleaner;

import android.app.*;
import android.os.*;
import android.view.*;
import java.io.*;

import java.lang.Process;
import org.xml.sax.helpers.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	Runtime shell;
	Handler handler;
	String toast;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		shell = Runtime.getRuntime();
		handler=new Handler(){
			@Override
			public void handleMessage(Message msg){
				Toast.makeText(MainActivity.this,"清理完毕",Toast.LENGTH_LONG).show();
			}
		};
		if(readData("firstboot")==null){
			new File(getFilesDir().toString()+"/terminfo").mkdir();
		    new File(getFilesDir().toString()+"/terminfo/l").mkdir();
			new File(getFilesDir().toString()+"/terminfo/s").mkdir();
			new File(getFilesDir().toString()+"/terminfo/v").mkdir();
			try{
				copyTo("busybox", getFilesDir().toString());
				copyTo("cleaner", getFilesDir().toString());
				copyTo("executable", getFilesDir().toString());
				copyTo("binaries_version_donotedit.bin", getFilesDir().toString());
				copyTo("linux", getFilesDir().toString()+"/terminfo/l");
				copyTo("screen", getFilesDir().toString()+"/terminfo/s");
				copyTo("vt100", getFilesDir().toString()+"/terminfo/v");
				shell("chmod 755 "+getFilesDir().toString()+"/busybox");
				shell("chmod 755 "+getFilesDir().toString()+"/cleaner");
				shell("chmod 755 "+getFilesDir().toString()+"/executable");
				shell("chmod 755 "+getFilesDir().toString()+"/binaries_version_donotedit.bin");
				shell("chmod 755 "+getFilesDir().toString()+"/terminfo/l/linux");
				shell("chmod 755 "+getFilesDir().toString()+"/terminfo/s/screen");
				shell("chmod 755 "+getFilesDir().toString()+"/terminfo/v/vt100");
			}
			catch (IOException e){
				Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
			}
			saveData("firstboot","false");
		}
		//shell("echo $PATH");
		if(readData("ischecked")!=null)if(readData("ischecked").contains("true")){
			clean(findViewById(R.id.mainButton1));
			((CheckBox)findViewById(R.id.mainCheckBox1)).setChecked(true);
		}
    }
	public String shell(String cmd) {  
        try{
			Process process=shell.exec(new String[]{"/system/bin/sh","-c",cmd},new String[]{"PATH="+getFilesDir().toString()+":/system/bin"});
			InputStream stream=process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
			String line;
			StringBuffer output = new StringBuffer();
			while ((line = reader.readLine()) != null){
				output.append(line + "\n");
			}
			stream.close();
			reader.close();
			return output.toString();
		}
		catch (IOException e){
			Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
			return null;
		}
    }
	public void clean(View btn){
		((Button)btn).setText("正在清理");
		btn.setClickable(false);
		new Thread(new Runnable(){
	    	@Override
			public void run(){
				shell("cleaner");
				handler.sendEmptyMessage(0);
				MainActivity.this.finish();
			}
		}).start();
	}
	public void checkbar(View checkbar){
		if(((CheckBox)checkbar).isChecked())saveData("ischecked","true");
		else saveData("ischecked","false");
	}
	public void saveData(String name,String text){
		getSharedPreferences("hello", MODE_WORLD_WRITEABLE).edit().putString(name,text).commit();
	}
	public String readData(String name){
		return getSharedPreferences("hello", MODE_WORLD_READABLE).getString(name,null);
	}
	private void copyTo(String file,String outURL) throws IOException 
    {  
        InputStream myInput;  
        OutputStream myOutput = new FileOutputStream(outURL+"/"+file);  
        myInput = this.getAssets().open(file);  
        byte[] buffer = new byte[1024];  
        int length = myInput.read(buffer);
        while(length > 0)
        {
            myOutput.write(buffer, 0, length); 
            length = myInput.read(buffer);
        }

        myOutput.flush();  
        myInput.close();  
        myOutput.close();        
    }  
}
